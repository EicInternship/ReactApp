import React from 'react';
import axios from 'axios';

export const UserService158529 = () => {
  return axios.get('https://api.github.com/users');
}
